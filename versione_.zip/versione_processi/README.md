# ProgettoSO1
 Il progetto di sistemi che dovrò fare di nuovo trollDespair

## TODO:
- fare in modo che le tane vengano stampate o meno se sono state visitate
- fixare gli spari(low priority)
- implementare generazione randomica del ragno
- implementare collisioni con gli spari