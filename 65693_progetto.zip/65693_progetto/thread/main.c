#include "space.h"

void main(){
	game();
}

