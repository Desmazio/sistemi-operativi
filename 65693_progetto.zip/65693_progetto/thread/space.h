#ifndef GATCHASHOOTER_H
#define GATCHASHOOTER_H

#include <stdio.h>
#include <ncurses.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

#define MAXY 36
#define MAXX 116
#define UP 65
#define DOWN 66
#define ALIEN_SIZE 3
#define PLAYER_SIZE 5
#define ALIENS_ALLOWED 2
#define WAVES 2
#define MAX_SHOTS 5
#define ATK_CHANCE 40
#define SPAWN_SPEED 10
#define MOVESPEED_LVL1 600000
#define MOVESPEED_LVL2 200000

/*
    i nomi delle varie entità sono ispirati a elementi di gioco e personaggi di un gioco di carte
    Giocatore = DP(dimensional police)
    Alieno lvl1 = ORFIST
    Alieno lvl2 = GRAVIDIA
    Bombe aliene = METEOR
    Missili del giocatore = CRITICAL
*/
typedef enum {DP, ORFIST, GRAVIDIA, METEOR, CRITICAL} EntityType;
typedef enum {N,S,NEAST,SEAST,NWEST,SWEST,FIXED} Directions;
typedef enum {WHITE,RED,YELLOW,GREEN,CYAN,BLUE,MAGENTA} Color;

typedef struct pos{
    int x,y;
}Pos;

// utilizzo tuple di coordinate (y,x) per delimitare l'area in cui si trova un alieno senza utilizzare una matrice che rappresenti la mappa
typedef struct hitbox{
    Pos topLeft;
    Pos botRight;
}Hitbox;

typedef struct entities{
    EntityType e;
    Directions d;
    Hitbox hb;
    Color cl;
    int lives;
    pthread_t thr;
    _Bool destroyable;
}Entity;

typedef struct entNode{
    struct entNode* prev;
    Entity data;
    struct entNode* next;
}entityNode;

typedef struct entList{
    entityNode* head;
    entityNode* tail;
    int len;
}entityList;

void* ship(void* param);
void* alien(void* param);
void* space(void* param);
void* bomba(void* param);
void* missile(void* param);
void* alienlvl2(void* param);
void* alienGenerator(void* param);

int game();
void gameEnding(entityList *list);
void drawFieldBorder();
void printer(Entity* ent);
void bodyClearing(entityNode *body);
void adjustCourse(Entity *a, Entity *b);
void blast(entityList *list, Entity* ship);
void shipCollisions(entityList *list, entityNode *target);
void alienCollisions(entityList *list, entityNode *target);
void bombaCollisions(entityList *list, entityNode *target);
void projectileCollisions(entityList *list, entityNode *target);
void bombaDeployer(entityList *list, Entity *Alien, int attackChance);

_Bool verifyHitbox(Hitbox *a, Hitbox *b);

entityList *initEntityList();
entityList* eraseEntity(entityNode *forDeletion, entityList *list);

entityNode *newEntity(Entity data);
entityNode *insert(Entity data, entityList *list);

#endif